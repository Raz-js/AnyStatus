import argparse
import json
import discord
from discord.ext import commands

# Parse command-line arguments
parser = argparse.ArgumentParser(description="Run a Discord bot with custom parameters.")
parser.add_argument('--act', type=str, help="The activity type (e.g., 'listen').")
parser.add_argument('--name', type=str, help="The name of the activity.")
args = parser.parse_args()

# Check if the parameters are valid
if args.act == "listen" and args.name:
    # Define the bot with the specified activity
    client = commands.Bot(
        command_prefix=':',
        self_bot=True,
        activity=discord.Activity(type=discord.ActivityType.listening, name=args.name),
        intents=discord.Intents.all()
    )
    client.remove_command('help')

    # Load configuration from config.json
    with open("config.json") as file:
        info = json.load(file)
        TOKEN = info["token"]

    # Run the bot
    client.run(TOKEN, bot=False)
else:
    print("Invalid parameters. Usage: --act=listen --name=<value>")
    
if args.act == "play" and args.name:
    # Define the bot with the specified activity
    client = commands.Bot(
        command_prefix=':',
        self_bot=True,
        activity=discord.Activity(type=discord.ActivityType.playing, name=args.name),
        intents=discord.Intents.all()
    )
    client.remove_command('help')

    # Load configuration from config.json
    with open("config.json") as file:
        info = json.load(file)
        TOKEN = info["token"]
        PREFIX = info["prefix"]

    # Run the bot
    client.run(TOKEN, bot=False)
else:
    print("Invalid parameters. Usage: --act=listen --name=<value>")